from functools import partial
from typing import Any, Optional, Sequence, Tuple

import flax
import flax.linen as nn
import jax
import jax.numpy as jnp
import optax
from flax.training import dynamic_scale as dynamic_scale_lib
from flax.core import freeze, unfreeze
from scale_rl.networks.utils import tree_norm
from scale_rl.agents.sparse import get_sparsities_erdos_renyi, get_var_shape_dict, create_random_mask
PRNGKey = jnp.ndarray


@flax.struct.dataclass
class Trainer:
    network_def: nn.Module = flax.struct.field(pytree_node=False)
    params: flax.core.FrozenDict[str, Any]
    tx: Optional[optax.GradientTransformation] = flax.struct.field(pytree_node=False)
    opt_state: Optional[optax.OptState] = None
    update_step: int = 0
    dynamic_scale: Optional[dynamic_scale_lib.DynamicScale] = None
    sparse: bool = flax.struct.field(default=False, pytree_node=False)
    #network_mask: Optional[flax.core.FrozenDict[str, Any]] = None  # Add this line
    network_mask: Optional[flax.core.FrozenDict[str, Any]] = flax.struct.field(default=None, pytree_node=False)
    """
    dataclass decorator makes custom class to be passed safely to Jax.
    https://flax.readthedocs.io/en/latest/api_reference/flax.struct.html

    Trainer class wraps network & optimizer to easily optimize the network under the hood.

    args:
        network_def:
        params: network parameters.
        tx: optimizer (e.g., optax.Adam).
        opt_state: current state of the optimizer (e.g., beta_1 in Adam).
        update_step: number of update step so far.
    """

    @classmethod
    def create(
        cls,
        network_def: nn.Module,
        network_inputs: flax.core.FrozenDict[str, jnp.ndarray],
        tx: Optional[optax.GradientTransformation] = None,
        dynamic_scale: Optional[dynamic_scale_lib.DynamicScale] = None,
        sparse = False,
        network_mask = None,
    ) -> "Trainer":
        with jax.default_device(jax.local_devices(backend="cpu")[0]):
            variables = network_def.init(**network_inputs)
        # jax.device_put(x) with no device leaves a CPU array on CPU, so an
        # agent checkpointed before its first update recorded CPU sharding,
        # which Orbax cannot restore on a GPU/METAL host. jnp.array moves each
        # leaf to the current default device (uncommitted, values unchanged).
        variables = jax.tree_util.tree_map(jnp.array, variables)
        params = variables.pop("params")
        if sparse:
            params_unfrozen = unfreeze(params)
            mask_unfrozen = unfreeze(network_mask)
            # set weight to zero
            masked_params_unfrozen = jax.tree_util.tree_map(lambda p, m: p * m, params_unfrozen, mask_unfrozen)
            params = freeze(masked_params_unfrozen)
        if tx is not None:
            opt_state = tx.init(params)
        else:
            opt_state = None

        network = cls(
            network_def=network_def,
            params=params,
            tx=tx,
            opt_state=opt_state,
            dynamic_scale=dynamic_scale,
            sparse=sparse,
            network_mask=network_mask
        )

        return network

    def __call__(self, *args, **kwargs):
        return self.network_def.apply({"params": self.params}, *args, **kwargs)

    def apply(self, *args, **kwargs):
        return self.network_def.apply(*args, **kwargs)

    def apply_gradient(self, loss_fn) -> Tuple[Any, "Trainer"]:
        if self.dynamic_scale:
            grad_fn = self.dynamic_scale.value_and_grad(loss_fn, has_aux=True)
            dynamic_scale, is_fin, (_, info), grads = grad_fn(self.params)
        else:
            grad_fn = jax.grad(loss_fn, has_aux=True)
            grads, info = grad_fn(self.params)
            dynamic_scale = None
            is_fin = True
        if self.sparse and self.network_mask is not None:
            mask_grad = jax.tree.map(lambda u, m: u * m, grads, self.network_mask)
            grad_norm = tree_norm(mask_grad)
            info["grad_norm"] = grad_norm
        else:
            grad_norm = tree_norm(grads)
            info["grad_norm"] = grad_norm
        # TODO adjust sparse gnorm
        updates, new_opt_state = self.tx.update(grads, self.opt_state, self.params)
        if self.sparse and self.network_mask is not None:
            updates = jax.tree.map(lambda u, m: u * m, updates, self.network_mask)
        new_params = optax.apply_updates(self.params, updates)

        network = self.replace(
            params=jax.tree_util.tree_map(
                partial(jnp.where, is_fin), new_params, self.params
            ),
            opt_state=jax.tree_util.tree_map(
                partial(jnp.where, is_fin), new_opt_state, self.opt_state
            ),
            update_step=self.update_step + 1,
            dynamic_scale=dynamic_scale,
        )

        return network, info
